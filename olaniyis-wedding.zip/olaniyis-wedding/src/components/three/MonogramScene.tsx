import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { useMemo, useRef } from 'react';
import * as THREE from 'three';

const GOLD = '#C9A45C';

// Same geometry as the 2D <Monogram>, remapped from the 0-100 SVG viewBox
// into a centred -1.3..1.3 3D space (x right, y up, z flat).
function toVec3(x: number, y: number): THREE.Vector3 {
  return new THREE.Vector3(((x - 50) / 50) * 1.3, (-(y - 50) / 50) * 1.3, 0);
}

const STROKES: THREE.Vector3[][] = [
  [toVec3(40, 24), toVec3(22, 76)],
  [toVec3(40, 24), toVec3(58, 76)],
  [toVec3(28.84, 56.24), toVec3(51.16, 56.24)],
  [toVec3(42, 76), toVec3(42, 26), toVec3(60, 50), toVec3(78, 26), toVec3(78, 76)],
];

function Stroke({ points }: { points: THREE.Vector3[] }) {
  const geometry = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3(points, false, 'catmullrom', 0);
    return new THREE.TubeGeometry(curve, 64, 0.045, 12, false);
  }, [points]);

  return (
    <mesh geometry={geometry}>
      <meshStandardMaterial color={GOLD} metalness={0.7} roughness={0.3} />
    </mesh>
  );
}

function RotatingMonogram() {
  const group = useRef<THREE.Group>(null);
  const { pointer } = useThree();
  const canTilt = useMemo(
    () => typeof window !== 'undefined' && window.matchMedia('(pointer: fine)').matches,
    [],
  );

  useFrame((_, delta) => {
    if (!group.current) return;
    group.current.rotation.y += delta * 0.25;
    if (canTilt) {
      group.current.rotation.x = THREE.MathUtils.lerp(group.current.rotation.x, pointer.y * -0.2, 0.05);
      group.current.rotation.y = THREE.MathUtils.lerp(
        group.current.rotation.y,
        group.current.rotation.y + pointer.x * 0.15,
        0.02,
      );
    }
  });

  return (
    <group ref={group}>
      {STROKES.map((points, i) => (
        <Stroke key={i} points={points} />
      ))}
    </group>
  );
}

/** The optional lightweight 3D A × M monogram. Lazy-loaded and only ever
 * mounted once WebGL support + reduced-motion have been checked by
 * <Monogram3D> — this file is pure Three.js/R3F, code-split into its own
 * chunk (see vite.config.ts) so it never delays the initial page render. */
export default function MonogramScene() {
  return (
    <Canvas
      dpr={[1, 1.5]}
      gl={{ antialias: true, alpha: true }}
      camera={{ position: [0, 0, 4.2], fov: 40 }}
      style={{ width: '100%', height: '100%' }}
    >
      <ambientLight intensity={0.7} />
      <directionalLight position={[2, 3, 4]} intensity={1.1} />
      <pointLight position={[-3, -2, 2]} intensity={0.4} color="#E2C98A" />
      <RotatingMonogram />
    </Canvas>
  );
}
