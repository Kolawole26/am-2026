import { lazy, Suspense, useEffect, useState } from 'react';
import { Monogram } from '@/components/common/Monogram';
import { ErrorBoundary } from '@/components/common/ErrorBoundary';
import { useReducedMotion } from '@/hooks/useReducedMotion';

const MonogramScene = lazy(() => import('./MonogramScene'));

function detectWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    return !!(
      window.WebGLRenderingContext &&
      (canvas.getContext('webgl') || canvas.getContext('experimental-webgl'))
    );
  } catch {
    return false;
  }
}

interface Monogram3DProps {
  size?: number;
}

/**
 * Progressive-enhancement wrapper: renders the static 2D monogram
 * immediately (no layout shift, nothing to wait for), then swaps in the
 * lazy-loaded 3D scene once we've confirmed WebGL is available and the
 * visitor hasn't asked for reduced motion. Any failure — no WebGL, a
 * low-power device, a runtime error in the 3D scene — falls back to the
 * static mark instead of breaking the page.
 */
export function Monogram3D({ size = 220 }: Monogram3DProps) {
  const reduced = useReducedMotion();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (reduced) return;
    // Defer the WebGL probe slightly so it never competes with
    // above-the-fold rendering work.
    const check = () => setReady(detectWebGL());
    if (typeof window.requestIdleCallback === 'function') {
      const idleId = window.requestIdleCallback(check);
      return () => window.cancelIdleCallback(idleId);
    }
    const timeoutId = window.setTimeout(check, 300);
    return () => window.clearTimeout(timeoutId);
  }, [reduced]);

  const fallback = (
    <div style={{ width: size, height: size }} className="flex items-center justify-center">
      <Monogram size={size * 0.6} tone="gold" />
    </div>
  );

  if (reduced || !ready) return fallback;

  return (
    <ErrorBoundary fallback={fallback}>
      <Suspense fallback={fallback}>
        <div style={{ width: size, height: size }}>
          <MonogramScene />
        </div>
      </Suspense>
    </ErrorBoundary>
  );
}
