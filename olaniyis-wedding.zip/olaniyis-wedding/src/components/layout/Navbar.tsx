import { AnimatePresence, motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Monogram } from '@/components/common/Monogram';
import { useScrollNav } from '@/hooks/useScrollNav';
import { wedding } from '@/data/wedding';

const NAV_LINKS = [
  { href: '#story', label: 'Our Story' },
  { href: '#the-wedding', label: 'The Wedding' },
  { href: '#gallery', label: 'Gallery' },
  { href: '#gifting', label: 'Gifting' },
  { href: '#rsvp', label: 'RSVP' },
];

export function Navbar() {
  const scrolled = useScrollNav(48);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [menuOpen]);

  const barTone = scrolled || menuOpen
    ? 'bg-ivory/95 backdrop-blur-sm shadow-sm shadow-wine/5'
    : 'bg-transparent';
  const textTone = scrolled || menuOpen ? 'text-wine' : 'text-ivory';

  return (
    <header className={`fixed inset-x-0 top-0 z-40 transition-colors duration-500 ${barTone}`}>
      <nav className="container-editorial flex h-18 items-center justify-between py-4" aria-label="Primary">
        <a
          href="#top"
          className={`flex items-center gap-2.5 font-display text-sm sm:text-base tracking-editorial uppercase transition-colors duration-500 ${textTone}`}
        >
          <Monogram size={30} tone={scrolled || menuOpen ? 'wine' : 'gold'} ring={false} />
          <span className="hidden sm:inline">{wedding.websiteName}</span>
        </a>

        <ul className="hidden lg:flex items-center gap-9">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className={`font-body text-xs tracking-editorial uppercase transition-colors duration-500 hover:text-gold ${textTone}`}
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <button
          type="button"
          className={`lg:hidden flex h-11 w-11 items-center justify-center transition-colors duration-500 ${textTone}`}
          aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={menuOpen}
          aria-controls="mobile-nav"
          onClick={() => setMenuOpen((v) => !v)}
        >
          {menuOpen ? <X size={26} strokeWidth={1.4} /> : <Menu size={26} strokeWidth={1.4} />}
        </button>
      </nav>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            id="mobile-nav"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="fixed inset-0 top-18 z-30 flex flex-col bg-ivory lg:hidden"
          >
            <ul className="flex flex-1 flex-col items-center justify-center gap-8">
              {NAV_LINKS.map((link, i) => (
                <motion.li
                  key={link.href}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.06 * i }}
                >
                  <a
                    href={link.href}
                    onClick={() => setMenuOpen(false)}
                    className="font-display text-2xl text-wine"
                  >
                    {link.label}
                  </a>
                </motion.li>
              ))}
            </ul>
            <p className="pb-10 text-center font-body text-xs tracking-editorial uppercase text-muted">
              {wedding.coupleShort} &middot; {wedding.dateShort}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
