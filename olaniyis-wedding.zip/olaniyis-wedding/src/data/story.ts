import type { StoryMilestone } from '@/types';

/**
 * PLACEHOLDER CONTENT — replace with Azeezat & Muiez's real story.
 * The <OurStory> component only cares about this array's shape, so you can
 * edit copy, add/remove milestones, or add images here without touching
 * any component code.
 */

export const storyIntro = {
  eyebrow: 'Our Story',
  supporting: 'Every forever has a beginning.',
  body: "What started as a quiet friendship grew, in time, into something neither of us could imagine living without. This is the story of how we got here — and the beginning of everything still to come.",
};

export const storyMilestones: StoryMilestone[] = [
  {
    id: 'how-we-met',
    date: 'Where it began',
    title: 'How We Met',
    text: 'Replace this with the story of how Azeezat & Muiez first met — the place, the moment, the small detail that made it memorable.',
    image: {
      src: '/images/gallery/placeholder-01.jpg',
      alt: 'Placeholder photo — replace with a photo from how Azeezat and Muiez met',
      width: 1200,
      height: 1500,
    },
  },
  {
    id: 'falling-in-love',
    date: 'Along the way',
    title: 'Falling In Love',
    text: "Replace this with the moment things became clear — a trip, a conversation, a season of life that brought Azeezat & Muiez closer together.",
    image: {
      src: '/images/gallery/placeholder-02.jpg',
      alt: 'Placeholder photo — replace with a photo from this chapter of the story',
      width: 1200,
      height: 900,
    },
  },
  {
    id: 'the-proposal',
    date: 'The turning point',
    title: 'The Proposal',
    text: 'Replace this with how Muiez proposed (or how it happened) — the setting, the surprise, the "yes".',
    image: {
      src: '/images/gallery/placeholder-03.jpg',
      alt: 'Placeholder photo — replace with a photo from the proposal',
      width: 1200,
      height: 1500,
    },
  },
  {
    id: 'today',
    date: 'And now',
    title: 'Forever Begins',
    text: "Replace this with a closing note from the couple to their guests — what this next chapter means to them.",
    image: {
      src: '/images/gallery/placeholder-04.jpg',
      alt: 'Placeholder photo — replace with a recent photo of the couple',
      width: 1200,
      height: 900,
    },
  },
];
