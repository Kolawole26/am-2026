import type { GiftItem } from '@/types';

/** PLACEHOLDER CONTENT — gift items are optional; images are optional too. */
export const gifts: GiftItem[] = [
  {
    id: 'honeymoon-fund',
    name: 'Honeymoon Fund',
    description: 'Help send Azeezat & Muiez off on their first trip as a married couple.',
    info: 'Replace with bank transfer details or a link to a honeymoon fund page.',
  },
  {
    id: 'home-fund',
    name: 'New Home Fund',
    description: 'A contribution towards furnishing the couple\'s first home together.',
    info: 'Replace with account details or a registry link.',
  },
  {
    id: 'registry',
    name: 'Gift Registry',
    description: 'A curated list of gifts the couple would love.',
    link: 'https://REPLACE_WITH_REGISTRY_LINK',
  },
];
