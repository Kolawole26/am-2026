import type { WeddingDetailItem } from '@/types';

/** PLACEHOLDER CONTENT — replace venue names, addresses & map links. */
export const weddingDetails: WeddingDetailItem[] = [
  {
    id: 'ceremony',
    label: 'Ceremony',
    title: 'Nikkah Ceremony',
    time: '12:00 PM — Saturday, 28 November 2026',
    venueName: 'Replace with ceremony venue name',
    address: 'Replace with full ceremony address, City, State',
    note: 'Guests are kindly asked to arrive 30 minutes early.',
    mapUrl: 'https://maps.google.com/?q=REPLACE_WITH_VENUE',
  },
  {
    id: 'reception',
    label: 'Reception',
    title: 'Wedding Reception',
    time: '4:00 PM — Saturday, 28 November 2026',
    venueName: 'Replace with reception venue name',
    address: 'Replace with full reception address, City, State',
    note: 'Doors open at 3:30 PM.',
    mapUrl: 'https://maps.google.com/?q=REPLACE_WITH_VENUE',
  },
  {
    id: 'dress-code',
    label: 'Dress Code',
    title: 'Wine, Gold & Ivory',
    note: 'We would love to see our colours on you. Replace this with the exact dress code Azeezat & Muiez want their guests to follow.',
  },
  {
    id: 'more-info',
    label: 'Good To Know',
    title: 'A Few More Details',
    note: 'Use this card for anything else guests should know — parking, gifting notes, accommodation recommendations, or children/plus-one policy.',
  },
];
