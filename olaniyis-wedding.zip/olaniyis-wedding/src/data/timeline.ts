import type { TimelineEvent } from '@/types';

/** PLACEHOLDER CONTENT — replace with the real order of the day. */
export const timelineEvents: TimelineEvent[] = [
  { id: 'arrival', time: '12:00 PM', title: 'Guests Arrive', description: 'Seating begins for the ceremony.' },
  { id: 'ceremony', time: '12:30 PM', title: 'Nikkah Ceremony', description: 'The formal union of Azeezat & Muiez.' },
  { id: 'photos', time: '2:00 PM', title: 'Couple Photographs', description: 'Family & bridal party photographs.' },
  { id: 'reception', time: '4:00 PM', title: 'Reception Begins', description: 'Guests are welcomed to the reception venue.' },
  { id: 'dinner', time: '6:00 PM', title: 'Dinner Is Served', description: 'A celebratory meal for family and friends.' },
  { id: 'toasts', time: '7:30 PM', title: 'Toasts & Speeches', description: 'Words from family and the wedding party.' },
  { id: 'dance', time: '8:30 PM', title: 'First Dance & Celebration', description: 'Dancing and celebration continue into the evening.' },
];
